#! bin/bash
sudo chmod +x /home/ec2-user/webapp/server.js
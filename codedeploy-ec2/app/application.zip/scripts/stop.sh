#! bin/bash
sudo -H -u ec2-user bash -c 'npm stop'